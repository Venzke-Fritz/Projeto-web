<?php
require_once 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Captura os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $rua = $_POST['rua'];
    $numero = $_POST['numero'];
    $bairro = $_POST['bairro'];
    $cidade = $_POST['cidade'];
    $pais = $_POST['pais'];

    // Verificar se o email já existe no banco de dados
    $sql_check_email = "SELECT COUNT(*) FROM usuarios WHERE email = :email";
    $stmt_check_email = $conexao->prepare($sql_check_email);
    $stmt_check_email->bindParam(':email', $email);
    $stmt_check_email->execute();
    $email_exists = $stmt_check_email->fetchColumn();

    // Se o email já existir, exibe uma mensagem de erro
    if ($email_exists > 0) {
        echo "Erro: Este email já está cadastrado.";
    } else {
        // Preparar a consulta SQL para inserir no banco de dados
        $sql = "INSERT INTO usuarios (nome, email, telefone, rua, numero, bairro, cidade, pais) 
                VALUES (:nome, :email, :telefone, :rua, :numero, :bairro, :cidade, :pais)";

        // Executar a consulta
        try {
            $stmt = $conexao->prepare($sql);
            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':telefone', $telefone);
            $stmt->bindParam(':rua', $rua);
            $stmt->bindParam(':numero', $numero);
            $stmt->bindParam(':bairro', $bairro);
            $stmt->bindParam(':cidade', $cidade);
            $stmt->bindParam(':pais', $pais);

            $stmt->execute();
            echo "Cadastro realizado com sucesso!";
        } catch (PDOException $e) {
            echo "Erro ao cadastrar: " . $e->getMessage();
        }
    }
} else {
    echo "Formulário não foi enviado corretamente.";
}
?>
